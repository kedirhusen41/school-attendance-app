#!/usr/bin/env bash
set -e
flutter create --platforms=android .
flutter clean
flutter pub get
flutter build apk --release
echo "APK output: build/app/outputs/flutter-apk/app-release.apk"
