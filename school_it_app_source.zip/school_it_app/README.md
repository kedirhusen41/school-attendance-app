# School & IT App — Flutter project source

This package contains the Dart app source supplied in the conversation and a Flutter `pubspec.yaml`.

## Generate the Android platform files

The previous build failed because `android/app/build.gradle` was missing. The safest fix is to let your installed Flutter SDK generate platform files that match its version.

1. Extract this ZIP.
2. Open a terminal in the `school_it_app` folder.
3. Run:

```bash
flutter create --platforms=android .
flutter clean
flutter pub get
flutter build apk --release
```

4. Find the APK at:

`build/app/outputs/flutter-apk/app-release.apk`

Back up the folder before regenerating platform files if you have custom Android settings. The `flutter create` command generates the missing `android/` project structure for your installed Flutter version.

## Notes

- This is source code, not a prebuilt APK.
- The APK must be built on a computer or build service with Flutter and the Android build toolchain installed.
- The attendance list currently contains sample names and statuses. The app does not yet save attendance to a database.
